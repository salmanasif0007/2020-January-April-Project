const mongoose= require('mongoose');
mongoose.connect('mongodb://localhost:27017/test', {useNewUrlParser: true, useUnifiedTopology: true});
// var MongoClient = require('mongodb').MongoClient;
// var url = "mongodb://localhost:27017/test";
const ejs= require ('ejs');
const express= require ('express');
const app= express();
app.use(express.urlencoded());
app.set('view engine','ejs')
var data=[];
const covid=mongoose.model('covid',{
     name: String,
     price: Number,
     paymoney: Number,
     num: Number,
     backmoney: Number, 
});
var name='';
var price='';
var paymoney='';
var num='';
var backmoney='';
var a='';
var b='';
var c='';
uid='';
app.get('/insert',function(req,res){
   res.render('insert');     
})

app.get('/delete',function(req,res){ 
  db.tests('covids').remove({"_id":uid},function(err,result){
    console.log(result);
});
res.render('delete')
})

app.get('/update',function(req,res){

  covids.findByIdAndUpdate(
    { _id: id },
    { name: a},
    { num: b},
    { backmoney:c},
    function(err, result) {
      if (err) {
        console.log(err);
      } else {
      console.log(result);
      }
    }
  );
  res.render('update')
});


app.post('/save',function(req,res){

        name=req.body.name;
        data.push(name);

        price=req.body.price;
   
        paymoney=req.body.amount;
    
        num=(paymoney/price);
        data.push(num);

        backmoney=(paymoney%price);
        data.push(backmoney);

        a=req.body.nam;
        b=req.body.num;
        c=req.body.bm;
        id=req.body.id;

        console.log("name of hand senitizer is: "+name);

        console.log("price: "+price);

        console.log("total money in hands: "+paymoney);

        console.log("total number of hand senitizer: "+num);

        console.log("remaining amount: "+backmoney);

        const virus= new covid({name:name,num:num,backmoney:backmoney});
        virus.save().then((data)=> console.log(data));
        
        covid.find(function(err,data){
        console.log(data);
          });

          res.render('display1',{

          alldata:data,
    
            })   
    })
app.listen(3000);



