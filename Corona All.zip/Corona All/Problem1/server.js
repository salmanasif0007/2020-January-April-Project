const ejs= require ('ejs');
const express= require ('express');
const app= express();
app.use(express.urlencoded());
app.set('view engine','ejs')
app.get('/',function(req,res){
   res.render('index');     
})
app.post('/save',function(req,res){
var a=req.body.name;
console.log(a);
var b=req.body.num;
console.log(b);
var c='60 days +2 months';
var d='40 days+ 1.5 months';
var e='20 days+ 1 months';
var f='10 days+ .5 months';
var g='You are safe';
res.render('index2',{
    a:a,
    c:c,
    d:d,
    e:e,
    f:f,
    g:g
})
})
app.listen(3000);



