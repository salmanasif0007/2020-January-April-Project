const ejs= require ('ejs');
const express= require ('express');
const app= express();
app.use(express.urlencoded());
app.set('view engine','ejs')
var a='';
var b='';
var c='';
var x='';
var y='';
app.get('/',function(req,res){
   res.render('index');     
})
app.post('/save',function(req,res){
  var a=req.body.name;
    console.log(a);
    var b=req.body.price;
    console.log(b);
    var c=req.body.amount;
    console.log(c)
        var x=c/b;
        var y=c%b;
        console.log("name of hand senitizer is: "+a);
        console.log("price: "+b);
        console.log("total money in hands: "+c);  
        console.log("total number of hand senitizer: "+x);
        console.log("remaining amount: "+y)
  
res.render('index2',{
    a:a,
    x:x,
    y:y
})
})
app.listen(3000);



