const mongoose= require('mongoose');
mongoose.connect('mongoose://localhost:27017/test',{useNewUrlParser:true,useUnifiedTopology:true});
const ejs= require ('ejs');
const express= require ('express');
const app= express();
app.use(express.urlencoded());
app.set('view engine','ejs')
const covid=mongoose.model('covid',{
     name: String,
     price: Number,
     paymoney: Number,
     num: Number,
     bcakmoney: Number
});
    
app.get('/',function(req,res){
   res.render('index1');     
})
app.post('/save',function(req,res){
    var name='';
    var price='';
    var paymoney='';
    var num='';
    var backmoney='';

        name=req.body.name;
    
        price=req.body.price;
    
        paymoney=req.body.amount;
    
        num=(paymoney/price);

        backmoney=(paymoney%price);

        console.log("name of hand senitizer is: "+a);
        console.log("price: "+b);
        console.log("total money in hands: "+c);  
        console.log("total number of hand senitizer: "+x);
        console.log("remaining amount: "+y)

        res.render('index2',{
                a:name,
                x:num,
                y:backmoney
            })

        const virus= new covid({name:name,num:num,backmoney:backmoney});
        virus.save().then((data)=> console.log(data));
    })
app.listen(3000);



