const ejs= require ('ejs');
const express= require ('express');
const app= express();
app.use(express.urlencoded());
app.set('view engine','ejs')

app.get('/',function(req,res){
   res.render('index31');
})
app.post('/save',function(req,res){
  var n1 = req.body.affectedperson;
  console.log(req.body.affectedperson);

    var a= parseInt(n1);
    var b="Totall day's 60 and netflix 2 month";
    var c="Totall day's 40 and netflix 1 month";
    var d="Totall day's 20 and netflix 1 month";
    var e="Totall day's 14 and netflix 1 month";

    if(a>=100)
    {
      console.log(b);
    }
     else if(a>=50)
    {
        console.log(c);
    }
    else if(a>=10)
    {
        console.log(d);
    }
    else if(a>=3)
    {
      console.log(e);
    }
res.render('index32',{
    b:b,
    c:c,
    d:d,
    e:e
})
})
app.listen(3000);
