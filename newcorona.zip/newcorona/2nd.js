const ejs= require ('ejs');
const express= require ('express');
const app= express();
app.use(express.urlencoded());
app.set('view engine','ejs')



app.get('/',function(req,res){
   res.render('index11');
})
app.post('/save',function(req,res){
  var a=req.body.name;
    console.log(req.body.name);
    var b=req.body.price;
    console.log(req.body.price);
    var c=req.body.amount;
    console.log(req.body.amount)

        var x=c/b;
        var y=c%b;
        console.log("name of hand senitizer is: "+a);
        console.log("price: "+b);
        console.log("total money in hands: "+parseInt(c));
        console.log("total number of hand senitizer: "+x);
        console.log("remaining amount: "+y)

res.render('index22',{
    a:a,
    x:x,
    y:y
})
})
app.listen(3000);
