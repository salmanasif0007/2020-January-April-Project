const ejs= require ('ejs');
const express= require ('express');
const app= express();
app.use(express.urlencoded());
app.set('view engine','ejs')


app.get('/',function(req,res){
   res.render('index');
})


app.post('/save',function(req,res){
  var a=req.body.num1;
  console.log(req.body.num1);
  var b=req.body.num2;
  console.log(req.body.num2);

  var sum=0;
  var av=0;
  var i=0;

  var x=parseInt(a);
  var y=parseInt(b);

  for(i=x;i<=y;i++){
  sum=sum+i;
  }

  var s=((y-x)+1);
   av=sum/s;
    console.log(sum);
  console.log(av);
  console.log(s);

res.render('index2',{
    sum:sum,
    av:av,
    s:s
})
})
app.listen(3000);
