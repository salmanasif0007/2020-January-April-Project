const express = require ("express")
const app = express()
const fs = require('fs');
const si=require('stock-info')

app.use(express.urlencoded())

app.get('/',function(req,res){

  res.sendFile(__dirname+'/index.html');
  console.log(__dirname);
})

app.post('/save',function(req,res){

  var n1=req.body.stk;
  console.log(n1=req.body.stk);
  var n2=req.body.price;
  console.log(n2=req.body.price);
  var n3=req.body.quantity;
  console.log(n3=req.body.quantity);
  var n4=req.body.name;
  console.log(n4=req.body.name);


si.getSingleStockInfo(n1).then(function(stock){


var m=n2*n3;
var n=(n3*stock.regularMarketPrice);
var o=stock.currentMarketPrice;

console.log(m);
console.log(n);

res.write("<h1>Name: "+n4+"</h1>");
res.write("<h1>Company: "+n1+"</h1>");
res.write("<h1>Quantity: "+n3+"</h1>")
res.write("<h1>Price: "+n2+"</h1>");

res.write("<h1>Total buying price is: "+m+"</h1>");
res.write("<h1> Total current price is: "+n+"</h1>");



if(m>n)
{
  var p=m-n;
 var t=p.toFixed(2);
  res.write("<h1> profit :"+t+"</h1>");
}
else {
  var q=n-m;
  var tt=q.toFixed(2)
  res.write("<h1> loss :"+tt+"</h1>");
}

res.send();

})
})


app.listen(3000);
